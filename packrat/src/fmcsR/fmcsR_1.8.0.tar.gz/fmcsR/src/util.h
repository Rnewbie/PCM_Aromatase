

#ifndef _UTIL_H
#define _UTIL_H

#include <string>

std::string getUpper(const std::string& s);

#endif // _UTIL_H
