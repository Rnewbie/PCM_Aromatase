.onLoad <- function(libname, pkgname) {
                                        #	pkgVersion <- packageDescription(pkgname, fields="Version")
                                        #	msg <- paste("\nWelcome to", pkgname, "version", pkgVersion, "\n")
                                        #	packageStartupMessage(msg)
    .initial()
}
