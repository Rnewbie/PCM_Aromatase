BiocGenerics:::testPackage('Rcpi')
