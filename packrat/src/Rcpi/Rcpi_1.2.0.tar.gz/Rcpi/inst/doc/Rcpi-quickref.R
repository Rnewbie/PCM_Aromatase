### R code from vignette source 'Rcpi-quickref.Rnw'

###################################################
### code chunk number 1: prelim
###################################################
Rcpi.version = 'Release 3'
now.date = strftime(Sys.Date(), "%Y-%m-%d")


