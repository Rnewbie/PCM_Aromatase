BiocGenerics:::testPackage("ChemmineR")
